# Birthday Surprise — Hubby ❤️

A mobile-friendly interactive birthday surprise page.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will give you a permanent Pages link.

No server or database is required.
